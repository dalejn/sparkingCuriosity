#' ggraph: Grammar of Graph Graphics
#'
#' There really should be some cool text and examples here. Will do once I
#' finish writting the cool code...
#'
#' @useDynLib ggraph
#'
#' @docType package
#' @name ggraph-package
#' @rdname ggraph-package
#'
NULL
